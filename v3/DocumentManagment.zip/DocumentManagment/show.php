<?php
//including db.php file for database connection
include 'config.php';

//query for selecting data from our database
$query = "SELECT * FROM doc";

//execute query
$result = $conn->query($query);
$pdf__file_path = "./upload/pdf/";
$excel__file_path = "./upload/excel/";
$word__file_path = "./upload/word/";



//checking result that should be more than 0
if ($result->num_rows > 0) {
    //html code for output
    $opt = '


    <table id="myTable" class="table-fill" width="100%">
      <thead>
        <tr>
          <th class="text-left">Sr.#</th>
          <th class="text-left">Document Name</th>
          <th class="text-left">PDF</th>
          <th class="text-left">Excel</th>
          <th class="text-left">Word</th>
        </tr>
      </thead>
      <tbody>

    ';
    $sr = 1;
    //looping our data till the last on our database
    while ($row = $result->fetch_assoc()) {
      if(!empty($row['pdf'])){
        $pdf__file_path= $pdf__file_path.$row['pdf'];
        $pdf = "<a class='fa fa-file-pdf-o'style='font-size:25px;color:#5083aa' href='". $pdf__file_path ."';></a>";
      }
      else{
        $pdf = "";
      }

      if(!empty($row['excel'])){
        $excel__file_path= $excel__file_path.$row['excel'];
        $excel = "<a class='fa fa-file-excel-o'style='font-size:25px;color:#5083aa' href='".$excel__file_path."';></a>";
      }
      else{
        $excel = "";
      }

      if(!empty($row['word'])){
        $word__file_path = $word__file_path.$row['word'];
        $word = "<a class='fa fa-file-word-o'style='font-size:25px;color:#5083aa' href='".$word__file_path."';></a>";
      }
      else{
        $word = "";
      }


      

        $opt .= "
        <tr>
          <td>
            $sr
          </td>
          <td >
            {$row['d_name']}
            <p>{$row['d_desc']}</p>
          </td>
          <td>
          <h6>Version:{$row['pdf_version']}.0</h6>
          $pdf
          <br>
          <button style='padding: 0px 25px;color:black;cursor: pointer;margin: 0px -4px;font-size: 10px;' class='add_files' pdf='" . $row['pdf'] . "'  doc_id='" . $row['id'] . "';>ADD NEW</button>
          <form id='My_form" . $row['id'] . "' style='display: none; width: 300px; padding: 14px; background: none;' enctype='multipart/form-data'>
            <input name='filess' type='file' id='filess'  />
            <input name='id' value='" . $row['id'] . "' type='hidden' />
            <input  id='btn-Upload' type='submit' value='upload' ></input>
          </form>
          <button style='padding: 0px 29px;color:black;cursor: pointer;margin: 0px -4px;font-size: 10px;' class='btn btn-danger delete_pdf' id='" . $row['id'] . "'; pdf='" . $row['pdf'] . "'>DELETE</button>
          <h6>Deleted Versions:</h6>";
          // to get deleted pdf-file paths
          if(!empty($row['del_pdf'])){
            $pre_recd= $row['del_pdf'];
            $str_arr = explode (",", $pre_recd); 
          for($i=0; $i<count($str_arr); $i++){
            $deleted= "./upload/pdf/".$str_arr[$i];
            $opt .= " <a class='fa fa-file-pdf-o'style='font-size:15px;color:red' href='$deleted';></a>";
          }
        }
          $opt .= "</td>

          <td>
          <h6>version:{$row['excel_version']}.0</h6>
          $excel
          <br>
          <button style='padding: 0px 25px;color:black;cursor: pointer;margin: 0px -4px;font-size: 10px;' class='add_excel_file' excel='" . $row['excel'] . "' doc_id='" . $row['id'] . "';>ADD NEW</button>
          <form id='My_excel_form" . $row['id'] . "' style='display: none; width: 300px; padding: 14px; background: none;' enctype='multipart/form-data'>
            <input name='filess' type='file' id='excel'  />
            <input name='id' value='" . $row['id'] . "' type='hidden' />
            <input type='submit' value='upload' ></input>
          </form>
          <button style='padding: 0px 29px;color:black;cursor: pointer;margin: 0px -4px;font-size: 10px;' class='btn btn-danger delete_excel' id='" . $row['id'] . "'; excel='" . $row['excel'] . "'>DELETE</button>
          <h6><b>Deleted Versions:</b></h6>";
          // to get deleted excel-file paths
          if(!empty($row['del_excel'])){
            $pre_recd= $row['del_excel'];
            $str_arr = explode (",", $pre_recd); 
          for($i=0; $i<count($str_arr); $i++){
            $deleted= "./upload/excel/".$str_arr[$i];
            $opt .= " <a class='fa fa-file-excel-o'style='font-size:15px;color:red' href='$deleted';></a>";
          }
        }
        $opt .= " </td>

          <td>
          <h6>version:{$row['word_version']}.0</h6>
          $word
          <br>
          <button style='padding: 0px 25px;color:black;cursor: pointer;margin: 0px -4px;font-size: 10px;' class='add_word_file' word='" . $row['word'] . "' doc_id='" . $row['id'] . "';>ADD NEW</button>
          <form id='My_word_form" . $row['id'] . "' style='display: none; width: 300px; padding: 14px; background: none;' enctype='multipart/form-data'>
            <input name='filess' type='file' id='word'  />
            <input name='id' value='" . $row['id'] . "' type='hidden' />
            <input type='submit' value='upload' ></input>
          </form>
          <button style='padding: 0px 29px;color:black;cursor: pointer;margin: 0px -4px;font-size: 10px;' class='btn btn-danger delete_word' id='" . $row['id'] . "'; word='" . $row['word'] . "'>DELETE</button>
          <h6><b>Deleted Versions:</b></h6>";
          // to get deleted word-file paths
          if(!empty($row['del_word'])){
            $pre_recd= $row['del_word'];
            $str_arr = explode (",", $pre_recd); 
          for($i=0; $i<count($str_arr); $i++){
            $deleted= "./upload/word/".$str_arr[$i];
            $opt .= " <a class='fa fa-file-word-o'style='font-size:15px;color:red' href='$deleted';></a>";
          }
        }
        $opt .= " </td>
        </tr>
        ";
        $sr++;
        $pdf__file_path = "./upload/pdf/";
        $excel__file_path = "./upload/excel/";
        $word__file_path = "./upload/word/";  
    }
    $opt .= '</tbody>
        </table>';
    // echo our output that we can use in our index.php using ajax response
    echo $opt;
}
