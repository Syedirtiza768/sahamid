create view inverntoryprice as
select `sahamid`.`manufacturers`.`manufacturers_name` AS `brand`,
       `sahamid`.`stockmaster`.`mnfpno`               AS `mnfpno`,
       `sahamid`.`stockmaster`.`mnfCode`              AS `mnfCode`,
       `sahamid`.`stockmaster`.`description`          AS `description`,
       `sahamid`.`stockmaster`.`materialcost`         AS `materialcost`
from (`sahamid`.`stockmaster`
       join `sahamid`.`manufacturers`
            on ((`sahamid`.`stockmaster`.`brand` = `sahamid`.`manufacturers`.`manufacturers_id`)))
order by `sahamid`.`stockmaster`.`brand` desc;

