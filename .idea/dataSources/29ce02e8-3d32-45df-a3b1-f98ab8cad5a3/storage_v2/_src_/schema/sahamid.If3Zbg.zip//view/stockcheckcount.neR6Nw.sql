create view stockcheckcount as
select `locstockcheck`.`stockid`            AS `stockid`,
       `locstockcheck`.`QTY`                AS `lqty`,
       `sahamid`.`substorestockcheck`.`QTY` AS `sqty`
from (`sahamid`.`substorestockcheck`
       join `sahamid`.`locstockcheck`
            on ((convert(`sahamid`.`substorestockcheck`.`stockid` using utf8) = `locstockcheck`.`stockid`)))
where (`sahamid`.`substorestockcheck`.`QTY` <> `locstockcheck`.`QTY`);

