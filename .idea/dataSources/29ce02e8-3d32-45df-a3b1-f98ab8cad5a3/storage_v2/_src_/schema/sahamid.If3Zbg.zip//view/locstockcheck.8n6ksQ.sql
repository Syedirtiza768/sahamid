create view locstockcheck as
select `sahamid`.`locstock`.`stockid` AS `stockid`, sum(`sahamid`.`locstock`.`quantity`) AS `QTY`
from `sahamid`.`locstock`
group by `sahamid`.`locstock`.`stockid`
order by `sahamid`.`locstock`.`stockid`;

