create view temp as
select `sahamid`.`stockmaster`.`stockid`         AS `stockid`,
       `sahamid`.`stockmaster`.`description`     AS `description`,
       `sahamid`.`stockmaster`.`longdescription` AS `longdescription`,
       `sahamid`.`stockmaster`.`mnfCode`         AS `mnfCode`,
       `sahamid`.`stockmaster`.`mnfpno`          AS `mnfpno`,
       `sahamid`.`stockmaster`.`conditionID`     AS `conditionID`,
       `sahamid`.`stockmaster`.`mbflag`          AS `mbflag`,
       `sahamid`.`stockmaster`.`discontinued`    AS `discontinued`,
       `sahamid`.`stockmaster`.`units`           AS `units`,
       `sahamid`.`stockmaster`.`decimalplaces`   AS `decimalplaces`,
       `sahamid`.`stockitemproperties`.`value`   AS `value`
from (`sahamid`.`stockmaster`
       join `sahamid`.`stockitemproperties`)
where ((`sahamid`.`stockmaster`.`stockid` = `sahamid`.`stockitemproperties`.`stockid`) and
       (`sahamid`.`stockmaster`.`categoryid` like 'ACB'));

