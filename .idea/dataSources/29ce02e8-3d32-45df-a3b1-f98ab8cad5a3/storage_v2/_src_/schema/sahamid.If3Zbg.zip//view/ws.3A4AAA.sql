create view ws as
select `sahamid`.`substorestock`.`index`      AS `index`,
       `sahamid`.`substorestock`.`loccode`    AS `loccode`,
       `sahamid`.`substorestock`.`stockid`    AS `stockid`,
       `sahamid`.`substorestock`.`quantity`   AS `quantity`,
       `sahamid`.`substorestock`.`substoreid` AS `substoreid`
from `sahamid`.`substorestock`
where ((`sahamid`.`substorestock`.`loccode` = 'WS') and ((`sahamid`.`substorestock`.`quantity` % 2) = 1))
order by `sahamid`.`substorestock`.`quantity` desc;

