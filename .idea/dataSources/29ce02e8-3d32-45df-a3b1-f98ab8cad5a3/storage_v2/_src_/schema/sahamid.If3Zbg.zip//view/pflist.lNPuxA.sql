create view pflist as
select `sahamid`.`stockmaster`.`stockid`      AS `stockid`,
       `sahamid`.`stockmaster`.`mnfpno`       AS `mnfpno`,
       `sahamid`.`stockmaster`.`mnfCode`      AS `mnfCode`,
       `sahamid`.`stockmaster`.`materialcost` AS `materialcost`
from `sahamid`.`stockmaster`
where (`sahamid`.`stockmaster`.`brand` = 100)
order by `sahamid`.`stockmaster`.`materialcost` desc;

