create view substorestockcheck as
select `sahamid`.`substorestock`.`stockid` AS `stockid`, sum(`sahamid`.`substorestock`.`quantity`) AS `QTY`
from `sahamid`.`substorestock`
group by `sahamid`.`substorestock`.`stockid`
order by `sahamid`.`substorestock`.`stockid`;

