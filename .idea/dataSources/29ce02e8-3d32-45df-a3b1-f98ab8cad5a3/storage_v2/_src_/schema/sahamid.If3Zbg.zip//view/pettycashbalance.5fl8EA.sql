create view pettycashbalance as
select `sahamid`.`pcashdetails`.`tabcode` AS `tabcode`, sum(`sahamid`.`pcashdetails`.`amount`) AS `SUM(amount)`
from `sahamid`.`pcashdetails`
group by `sahamid`.`pcashdetails`.`tabcode`;

