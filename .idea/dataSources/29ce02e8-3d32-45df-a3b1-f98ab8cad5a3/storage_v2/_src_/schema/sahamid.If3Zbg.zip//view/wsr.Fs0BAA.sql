create view wsr as
select `ws`.`index`      AS `index`,
       `ws`.`loccode`    AS `loccode`,
       `ws`.`stockid`    AS `stockid`,
       `ws`.`quantity`   AS `quantity`,
       `ws`.`substoreid` AS `substoreid`
from `sahamid`.`ws`;

